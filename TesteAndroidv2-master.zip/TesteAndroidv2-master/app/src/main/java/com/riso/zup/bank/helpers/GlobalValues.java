package com.riso.zup.bank.helpers;

public class GlobalValues {
    public static String API_URL = "https://bank-app-test.herokuapp.com/api/";

    public static String PREF_FILE_BANK = "infoPrefUserBank";

    public static String PREF_KEY_USER = "userInfo";
}
